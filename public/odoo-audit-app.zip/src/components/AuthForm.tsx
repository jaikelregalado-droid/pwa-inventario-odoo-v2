import React, { useState, useEffect, useMemo } from 'react';
import {
  Server,
  Database,
  User,
  Key,
  Globe,
  Building2,
  MapPin,
  Tag,
  ArrowRight,
  ShieldCheck,
  AlertTriangle,
  Sparkles,
  Users,
  Radio,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  RefreshCw,
  FolderOpen,
  Download,
  Loader2,
  Code2,
  Check,
  Copy,
  Settings
} from 'lucide-react';
import { OdooConnectionConfig, OdooCompany, OdooLocation, OdooCategory, AuditSession, RealtimeCountUpdate, QuantItem } from '../types';
import { sanitizeOdooUrl, authenticateOdoo, fetchLocations, fetchCategories, getDemoFVGrupoData, getCachedUid } from '../lib/odoo';
import {
  generateSessionPin,
  getSavedSupabaseSettings,
  saveSupabaseSettings,
  checkSessionExistsInSupabase,
  registerSessionInSupabase,
  isSupabaseConfigured,
  DEFAULT_SUPABASE_URL,
  DEFAULT_SUPABASE_ANON_KEY,
  SUPABASE_SQL_SCHEMA,
  SupabaseSettings
} from '../lib/supabase';
import { sound } from '../lib/audio';
import { loadOfflineCatalog, saveOfflineCatalog, mergeAuditItems, getPendingCounts } from '../lib/offlineSync';
import { PWAInstallButton } from './PWAInstallButton';

interface AuthFormProps {
  onSessionStarted: (
    session: AuditSession,
    config: OdooConnectionConfig,
    isDemo: boolean,
    initialCounts?: RealtimeCountUpdate[],
    initialCustomItems?: QuantItem[]
  ) => void;
  savedConfig?: OdooConnectionConfig;
}

export const AuthForm: React.FC<AuthFormProps> = ({ onSessionStarted, savedConfig }) => {
  // Modo de inicio: 'create' (nueva auditoría) o 'join' (unirse con PIN)
  const [sessionMode, setSessionMode] = useState<'create' | 'join'>('create');
  const [isCreatingSession, setIsCreatingSession] = useState<boolean>(false);
  const [isCreatingFromNotFound, setIsCreatingFromNotFound] = useState<boolean>(false);

  // Campos de Odoo 17 (Configuración por defecto solicitada)
  const defaultUrl = 'https://erp.pruebas.fvgrupoempresarial.com';
  const defaultDb = 'grupo_fv_30dias';
  const defaultUsername = 'jhonki2005du@gmail.com';
  const defaultApiKey = '669455ace6990b1b2b02c1a939546e397a59bbb8';

  const [url, setUrl] = useState<string>(
    savedConfig?.url || defaultUrl
  );
  const [sanitizedPreview, setSanitizedPreview] = useState<string>('');
  const [db, setDb] = useState<string>(
    savedConfig?.db && savedConfig.db !== 'odoo17_fvgrupo'
      ? savedConfig.db
      : defaultDb
  );
  const [username, setUsername] = useState<string>(
    savedConfig?.username && savedConfig.username !== 'admin'
      ? savedConfig.username
      : defaultUsername
  );
  const [apiKey, setApiKey] = useState<string>(
    savedConfig?.apiKey || defaultApiKey
  );
  const [proxyUrl, setProxyUrl] = useState<string>(() => {
    if (savedConfig?.proxyUrl && savedConfig.proxyUrl !== 'https://corsproxy.io/?') {
      return savedConfig.proxyUrl;
    }
    return '/api/odoo-proxy';
  });
  const [customProxyUrl, setCustomProxyUrl] = useState<string>('');
  const [isCustomProxy, setIsCustomProxy] = useState<boolean>(false);

  // Acordeón de credenciales Odoo: cerrado por defecto para interfaz limpia
  const [showOdooConfig, setShowOdooConfig] = useState<boolean>(false);

  // Estado de autenticación en Odoo (inicia como conectado con las credenciales por defecto de FV Grupo)
  const [isLoadingAuth, setIsLoadingAuth] = useState<boolean>(false);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(true);
  const [authError, setAuthError] = useState<string | null>(null);
  const [authenticatedUid, setAuthenticatedUid] = useState<number | undefined>(() => getCachedUid() || undefined);

  // Compañías y catálogos
  const [companies, setCompanies] = useState<OdooCompany[]>(() => [
    { id: savedConfig?.companyId || 1, name: savedConfig?.companyName || 'FV GRUPO EMPRESARIAL, C.A.' }
  ]);
  const [selectedCompanyId, setSelectedCompanyId] = useState<number>(savedConfig?.companyId || 1);
  const [locations, setLocations] = useState<OdooLocation[]>([]);
  const [selectedLocationId, setSelectedLocationId] = useState<number | undefined>(undefined);
  const [categories, setCategories] = useState<OdooCategory[]>([]);
  const [selectedCategoryId, setSelectedCategoryId] = useState<number | undefined>(undefined);
  const [isLoadingCatalogs, setIsLoadingCatalogs] = useState<boolean>(false);

  // Deduplicación estricta de categorías en el frontend por complete_name y por ID único
  const deduplicatedCategories = useMemo(() => {
    const seenNames = new Set<string>();
    const seenIds = new Set<number>();
    const uniqueList: OdooCategory[] = [];

    for (const cat of categories) {
      if (!cat || typeof cat.id !== 'number') continue;
      const cleanName = (cat.complete_name || cat.name || '').trim();
      const normKey = cleanName.toLowerCase();

      if (seenIds.has(cat.id) || (normKey && seenNames.has(normKey))) {
        continue;
      }

      seenIds.add(cat.id);
      if (normKey) seenNames.add(normKey);

      uniqueList.push({
        id: cat.id,
        name: cat.name || cleanName,
        complete_name: cleanName,
      });
    }

    return uniqueList.sort((a, b) => a.complete_name.localeCompare(b.complete_name));
  }, [categories]);

  // Datos del auditor y sesión
  const [auditorName, setAuditorName] = useState<string>(
    localStorage.getItem('odoo_auditor_name') || 'Auditor Piso 1'
  );
  const [joinPin, setJoinPin] = useState<string>('');
  const [isCheckingPin, setIsCheckingPin] = useState<boolean>(false);
  const [sessionNotFoundState, setSessionNotFoundState] = useState<{ pin: string } | null>(null);
  const [customPin, setCustomPin] = useState<string | null>(null);
  const [autoCreateOnJoin, setAutoCreateOnJoin] = useState<boolean>(true);
  const [showSqlSchema, setShowSqlSchema] = useState<boolean>(false);
  const [copiedSql, setCopiedSql] = useState<boolean>(false);

  // Configuración de Supabase opcional
  const [showSupabaseSettings, setShowSupabaseSettings] = useState<boolean>(false);
  const [supabaseSettings, setSupabaseSettingsState] = useState<SupabaseSettings>(
    getSavedSupabaseSettings()
  );

  // Sanitizar URL en tiempo real mientras el usuario escribe
  useEffect(() => {
    const cleaned = sanitizeOdooUrl(url);
    setSanitizedPreview(cleaned);
  }, [url]);

  // Si ya había config guardada con UID
  useEffect(() => {
    if (savedConfig?.uid) {
      setIsAuthenticated(true);
      if (savedConfig.companyId) {
        setSelectedCompanyId(savedConfig.companyId);
      }
    }
  }, [savedConfig]);

  // Carga inicial en segundo plano de catálogos y verificación de conexión
  useEffect(() => {
    handleAuthenticate();
  }, []);

  // Probar y autenticar en Odoo 17
  const handleAuthenticate = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setIsLoadingAuth(true);
    setAuthError(null);

    const cleanBase = sanitizeOdooUrl(url);
    const effectiveProxy = isCustomProxy ? (customProxyUrl.trim() || 'direct') : proxyUrl;

    const configToTest: OdooConnectionConfig = {
      url: cleanBase,
      db: db.trim(),
      username: username.trim(),
      apiKey: apiKey.trim(),
      proxyUrl: effectiveProxy,
    };

    try {
      const authResult = await authenticateOdoo(configToTest);
      setAuthenticatedUid(authResult.uid);
      setCompanies(authResult.companies);
      const activeId = authResult.activeCompany?.id || 1;
      setSelectedCompanyId(activeId);
      setIsAuthenticated(true);
      sound.playSuccess();

      // Cargar ubicaciones y categorías
      await loadCatalogs({
        ...configToTest,
        uid: authResult.uid,
        companyId: activeId,
      });
    } catch (err: any) {
      sound.playError();
      setAuthError(err.message || 'Error al conectar con Odoo 17');
      setIsAuthenticated(false);
    } finally {
      setIsLoadingAuth(false);
    }
  };

  const loadCatalogs = async (cfg: OdooConnectionConfig) => {
    setIsLoadingCatalogs(true);
    try {
      const [locs, cats] = await Promise.all([
        fetchLocations(cfg).catch(() => []),
        fetchCategories(cfg).catch(() => []),
      ]);

      setLocations(locs);
      // Mantener "Todas las ubicaciones" por defecto o la que el usuario ya tenía seleccionada
      if (selectedLocationId && !locs.some((l) => l.id === selectedLocationId)) {
        setSelectedLocationId(undefined);
      }

      setCategories(cats);
    } catch (err) {
      console.warn('Error cargando catálogos:', err);
    } finally {
      setIsLoadingCatalogs(false);
    }
  };

  // Guardar configuración de Supabase
  const handleSaveSupabase = () => {
    saveSupabaseSettings(supabaseSettings);
    setShowSupabaseSettings(false);
    sound.playSuccess();
  };

  // Crear Sesión Nueva (Lead)
  const handleStartNewSession = async () => {
    if (!auditorName.trim()) {
      setAuthError('Por favor ingresa tu nombre de auditor.');
      return;
    }

    setIsCreatingSession(true);
    setAuthError(null);

    try {
      localStorage.setItem('odoo_auditor_name', auditorName.trim());
      const pin = customPin || generateSessionPin();
      const sessionId = `session_${pin}_${Date.now()}`;

      const selectedComp =
        companies.find((c) => c.id === selectedCompanyId)?.name || 'FV GRUPO EMPRESARIAL, C.A.';
      const selectedLoc =
        locations.find((l) => l.id === selectedLocationId)?.complete_name ||
        'WH/Existencias';

      const session: AuditSession = {
        id: sessionId,
        pin,
        auditorName: auditorName.trim(),
        role: 'lead',
        createdAt: new Date().toISOString(),
        companyName: selectedComp,
        companyId: selectedCompanyId || 1,
        locationName: selectedLoc,
        locationId: selectedLocationId,
        categoryId: selectedCategoryId || undefined,
        categoryName: categories.find((c) => c.id === selectedCategoryId)?.name || undefined,
      };

      const effectiveProxy = isCustomProxy ? (customProxyUrl.trim() || 'direct') : proxyUrl;

      const finalConfig: OdooConnectionConfig = {
        url: sanitizeOdooUrl(url),
        db: db.trim(),
        username: username.trim(),
        apiKey: apiKey.trim(),
        proxyUrl: effectiveProxy,
        companyId: selectedCompanyId,
        companyName: selectedComp,
        uid: authenticatedUid || getCachedUid() || undefined,
      };

      localStorage.setItem('odoo_audit_active_pin', pin);
      localStorage.setItem('odoo_audit_session_id', sessionId);

      // OBLIGATORIO: Realizar UPSERT en la tabla de sesiones de Supabase para guardar la sesión
      const supaResult = await registerSessionInSupabase(session, finalConfig);
      
      // La PWA debe esperar la confirmación de guardado de Supabase antes de ingresar al inventario. Si la inserción falla (por RLS o credenciales), muestra el mensaje de error explícito en pantalla.
      if (!supaResult.success) {
        sound.playError();
        setAuthError(
          `Error al registrar sesión en Supabase: ${supaResult.error || 'Fallo de inserción'}. Verifica permisos RLS o credenciales en Supabase.`
        );
        return;
      }

      localStorage.setItem('odoo_audit_active_pin', pin);
      localStorage.setItem('odoo_audit_session_id', sessionId);

      sound.playSuccess();
      onSessionStarted(session, finalConfig, false);
    } catch (err: any) {
      console.error('Error al iniciar sesión:', err);
      sound.playError();
      setAuthError(`Error al inicializar sesión: ${err.message || String(err)}`);
    } finally {
      setIsCreatingSession(false);
    }
  };

  // Crear Sesión directamente desde el botón amarillo "Crear Sesión con PIN [código]"
  const handleCreateSessionWithPin = async (targetPin: string) => {
    if (!auditorName.trim()) {
      setAuthError('Por favor ingresa tu nombre de auditor antes de crear la sesión.');
      sound.playError();
      return;
    }

    setIsCreatingFromNotFound(true);
    setAuthError(null);

    try {
      localStorage.setItem('odoo_auditor_name', auditorName.trim());
      const sessionId = `session_${targetPin}_${Date.now()}`;

      const selectedComp =
        companies.find((c) => c.id === selectedCompanyId)?.name || 'FV GRUPO EMPRESARIAL, C.A.';
      const selectedLoc =
        locations.find((l) => l.id === selectedLocationId)?.complete_name ||
        'WH/Existencias';

      const session: AuditSession = {
        id: sessionId,
        pin: targetPin,
        auditorName: auditorName.trim(),
        role: 'lead',
        createdAt: new Date().toISOString(),
        companyName: selectedComp,
        companyId: selectedCompanyId || 1,
        locationName: selectedLoc,
        locationId: selectedLocationId,
        categoryId: selectedCategoryId || undefined,
        categoryName: categories.find((c) => c.id === selectedCategoryId)?.name || undefined,
      };

      const effectiveProxy = isCustomProxy ? (customProxyUrl.trim() || 'direct') : proxyUrl;

      const finalConfig: OdooConnectionConfig = {
        url: sanitizeOdooUrl(url),
        db: db.trim(),
        username: username.trim(),
        apiKey: apiKey.trim(),
        proxyUrl: effectiveProxy,
        companyId: selectedCompanyId,
        companyName: selectedComp,
        uid: authenticatedUid || getCachedUid() || undefined,
      };

      // OBLIGATORIO: Realizar UPSERT o INSERT en la tabla de sesiones de Supabase y esperar confirmación
      const supaResult = await registerSessionInSupabase(session, finalConfig);

      // Si la inserción falla (por RLS o credenciales), muestra el mensaje de error explícito en pantalla
      if (!supaResult.success) {
        sound.playError();
        setAuthError(
          `Error al registrar sesión en Supabase: ${supaResult.error || 'Fallo de inserción'}. Verifica políticas RLS o credenciales en Supabase.`
        );
        return;
      }

      localStorage.setItem('odoo_audit_active_pin', targetPin);
      localStorage.setItem('odoo_audit_session_id', sessionId);
      setSessionNotFoundState(null);

      sound.playSuccess();
      onSessionStarted(session, finalConfig, false);
    } catch (err: any) {
      console.error('Error al registrar sesión en Supabase:', err);
      sound.playError();
      setAuthError(`Error al crear sesión en Supabase: ${err.message || String(err)}`);
    } finally {
      setIsCreatingFromNotFound(false);
    }
  };

  // Unirse a Sesión Existente mediante PIN con acceso directo automático
  const handleJoinSession = async () => {
    if (!auditorName.trim()) {
      setAuthError('Por favor ingresa tu nombre de auditor.');
      return;
    }
    const cleanPin = joinPin.trim();
    if (!cleanPin || cleanPin.length !== 4) {
      setAuthError('El PIN debe tener exactamente 4 dígitos.');
      sound.playError();
      return;
    }

    setAuthError(null);
    setSessionNotFoundState(null);
    setIsCheckingPin(true);

    try {
      // 1. Verificar si ya existe inventario localmente en este dispositivo para este PIN
      const localOfflineItems = loadOfflineCatalog(cleanPin);
      const customInventoryRaw = localStorage.getItem(`odoo_audit_custom_inventory_${cleanPin}`);
      let customItems: QuantItem[] | undefined;
      if (customInventoryRaw) {
        try {
          const parsed = JSON.parse(customInventoryRaw);
          if (Array.isArray(parsed) && parsed.length > 0) {
            customItems = parsed;
          }
        } catch {}
      }

      // 2. Al ingresar un PIN de sesión en la PWA, consultar Supabase (SELECT)
      const checkResult = await checkSessionExistsInSupabase(cleanPin);

      const hasPriorSession = checkResult.exists ||
        (localOfflineItems && localOfflineItems.length > 0) ||
        (customItems && customItems.length > 0);

      // Si la sesión o inventario ya existe previamente para ese PIN:
      if (hasPriorSession) {
        localStorage.setItem('odoo_auditor_name', auditorName.trim());
        localStorage.setItem('odoo_audit_active_pin', cleanPin);
        const resolvedSessionId = checkResult.session?.id || `session_${cleanPin}`;
        localStorage.setItem('odoo_audit_session_id', resolvedSessionId);

        // Inferir categorías existentes si las tiene la sesión o el catálogo
        const existingCatIds = checkResult.session?.categoryIds ||
          (checkResult.session?.categoryId ? [checkResult.session.categoryId] : undefined) ||
          (localOfflineItems && localOfflineItems.length > 0
            ? Array.from(new Set(localOfflineItems.map((i) => i.categId).filter((id): id is number => typeof id === 'number')))
            : undefined) ||
          (customItems && customItems.length > 0
            ? Array.from(new Set(customItems.map((i) => i.categId).filter((id): id is number => typeof id === 'number')))
            : undefined);

        const existingCatName = checkResult.session?.categoryName ||
          (localOfflineItems && localOfflineItems[0]?.categName ? localOfflineItems[0].categName : undefined) ||
          (customItems ? 'Inventario Personalizado' : undefined);

        const session: AuditSession = {
          id: resolvedSessionId,
          pin: cleanPin,
          auditorName: auditorName.trim(),
          role: 'auditor',
          createdAt: checkResult.session?.createdAt || new Date().toISOString(),
          companyName: checkResult.session?.companyName || 'FV GRUPO EMPRESARIAL, C.A.',
          companyId: checkResult.session?.companyId || selectedCompanyId || 1,
          locationName: checkResult.session?.locationName || 'WH/Existencias',
          locationId: checkResult.session?.locationId || selectedLocationId,
          categoryId: existingCatIds?.[0],
          categoryIds: existingCatIds,
          categoryName: existingCatName,
          categoryNames: checkResult.session?.categoryNames,
        };

        const effectiveProxy = isCustomProxy ? (customProxyUrl.trim() || 'direct') : proxyUrl;
        const effectiveUrl = url || checkResult.session?.odooUrl || defaultUrl;
        const effectiveDb = db || checkResult.session?.odooDb || defaultDb;

        const finalConfig: OdooConnectionConfig = {
          url: sanitizeOdooUrl(effectiveUrl),
          db: effectiveDb.trim(),
          username: username.trim(),
          apiKey: apiKey.trim(),
          proxyUrl: effectiveProxy,
          companyId: session.companyId || selectedCompanyId || 1,
          companyName: session.companyName,
          uid: authenticatedUid || getCachedUid() || undefined,
        };

        // REQUISITO 1: Fusionar dinámicamente registros previos del servidor con datos locales
        const localCandidate = customItems || localOfflineItems || [];
        const pendingQueue = getPendingCounts(cleanPin);
        let finalMergedItems: QuantItem[] | undefined;

        if (checkResult.items && checkResult.items.length > 0) {
          finalMergedItems = mergeAuditItems(localCandidate, checkResult.items, pendingQueue);
        } else if (localCandidate.length > 0) {
          finalMergedItems = localCandidate;
        }

        if (finalMergedItems && finalMergedItems.length > 0) {
          saveOfflineCatalog(cleanPin, finalMergedItems);
        }

        sound.playSuccess();
        // Redirigir directamente al panel de conteo y auditoría con los datos fusionados
        onSessionStarted(
          session,
          finalConfig,
          false,
          checkResult.counts,
          finalMergedItems
        );
        return;
      }

      // 3. Si la sesión no existe en Supabase ni en almacenamiento local:
      if (autoCreateOnJoin) {
        // Auto-crear la sesión con este PIN e ingresar inmediatamente
        await handleCreateSessionWithPin(cleanPin);
        return;
      }

      // Si la auto-creación automática está desactivada, mostrar opción para crearla
      sound.playError();
      setSessionNotFoundState({ pin: cleanPin });
      setAuthError(
        `La sesión con PIN ${cleanPin} no fue encontrada en Supabase. Puedes crearla e ingresar haciendo clic en el botón a continuación.`
      );
    } catch (err: any) {
      console.error('Error al verificar sesión en Supabase:', err);
      sound.playError();
      setAuthError(`Error al consultar Supabase: ${err.message || String(err)}`);
    } finally {
      setIsCheckingPin(false);
    }
  };

  // Iniciar en Modo Demo (FV GRUPO EMPRESARIAL, C.A.)
  const handleStartDemo = () => {
    const demoData = getDemoFVGrupoData();
    setLocations(demoData.locations);
    setCategories(demoData.categories);
    setSelectedLocationId(demoData.locations[0].id);

    const pin = generateSessionPin();
    const session: AuditSession = {
      pin,
      auditorName: auditorName.trim() || 'Auditor Demo',
      role: 'lead',
      createdAt: new Date().toISOString(),
      companyName: 'FV GRUPO EMPRESARIAL, C.A. (Demo)',
      locationName: demoData.locations[0].complete_name,
      locationId: demoData.locations[0].id,
    };

    const dummyConfig: OdooConnectionConfig = {
      url: 'https://erp.pruebas.fvgrupoempresarial.com',
      db: 'grupo_fv_30dias',
      username: 'jhonki2005du@gmail.com',
      apiKey: '669455ace6990b1b2b02c1a939546e397a59bbb8',
      proxyUrl: '/api/odoo-proxy',
      uid: 1,
      companyId: 1,
      companyName: 'FV GRUPO EMPRESARIAL, C.A.',
    };

    sound.playSuccess();
    onSessionStarted(session, dummyConfig, true);
  };

  return (
    <div className="w-full min-h-screen bg-[#F8FAFC]">
      {/* 1. BARRA SUPERIOR (HEADER) CON ESTADO DE CONEXIÓN Y ACCESO A CONFIGURACIÓN ODOO */}
      <header className="sticky top-0 z-30 w-full bg-white/95 backdrop-blur-md border-b border-[#E2E8F0] shadow-[0_1px_3px_rgba(0,0,0,0.05)]">
        <div className="max-w-xl mx-auto px-4 py-2.5 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-purple-50 border border-purple-200 text-[#7C3AED]">
              <Building2 className="w-4 h-4 text-[#7C3AED]" />
            </div>
            <div>
              <h2 className="text-xs sm:text-sm font-black text-[#0F172A] leading-tight">
                Auditoría <span className="text-[#7C3AED]">Odoo 17</span>
              </h2>
              <span className="text-[10px] text-[#64748B] block font-medium">FV Grupo Empresarial</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Estado Resumido de Conexión (Badge Verde) */}
            {isAuthenticated ? (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-50 border border-emerald-200 text-emerald-700 shadow-2xs">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <span>Conectado</span>
              </span>
            ) : isLoadingAuth ? (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-medium bg-amber-50 border border-amber-200 text-amber-700 shadow-2xs">
                <Loader2 className="w-3 h-3 animate-spin text-amber-600" />
                <span>Conectando...</span>
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-medium bg-rose-50 border border-rose-200 text-rose-700">
                <AlertTriangle className="w-3 h-3 text-rose-600" />
                <span>Desconectado</span>
              </span>
            )}

            {/* Botón Discreto "Configuración Odoo" */}
            <button
              type="button"
              onClick={() => setShowOdooConfig((prev) => !prev)}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border transition cursor-pointer text-xs font-semibold shadow-2xs ${
                showOdooConfig
                  ? 'bg-purple-50 border-[#7C3AED] text-[#7C3AED]'
                  : 'bg-white hover:bg-slate-50 border-[#E2E8F0] text-[#64748B] hover:text-[#0F172A]'
              }`}
              title="Mostrar / ocultar configuración de credenciales Odoo"
            >
              <Settings className="w-3.5 h-3.5 text-[#7C3AED]" />
              <span className="hidden xs:inline">Configuración Odoo</span>
              {showOdooConfig ? (
                <ChevronUp className="w-3.5 h-3.5 text-[#7C3AED]" />
              ) : (
                <ChevronDown className="w-3.5 h-3.5 text-[#64748B]" />
              )}
            </button>
          </div>
        </div>
      </header>

      <div className="w-full max-w-xl mx-auto px-4 py-6 sm:py-8 space-y-5">
        {/* Encabezado y Marca */}
        <div className="text-center space-y-2">
          <h1 className="text-2xl sm:text-3xl font-black text-[#0F172A] tracking-tight">
            Auditoría de Inventario <span className="text-[#7C3AED]">Odoo 17</span>
          </h1>
          <p className="text-xs sm:text-sm text-[#64748B] max-w-md mx-auto">
            Conteo físico colaborativo en tiempo real para almacenes y piso de venta en multicompañía.
          </p>

          {/* Botón PWA install */}
          <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-2">
            <PWAInstallButton />
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-medium bg-emerald-50 border border-emerald-200 text-emerald-700 shadow-xs">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              Supabase Cloud Realtime Activo (sepeawvmamugivoptfyf)
            </span>
          </div>
        </div>

        {/* 2. ESTADO INICIAL LIMPIO: RESUMEN DE CONEXIÓN ODOO 17 (SIN EXPONER CREDENCIALES) */}
        <div className="p-3.5 rounded-2xl bg-white border border-[#E2E8F0] shadow-xs flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="p-2 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-600 shrink-0">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-[#0F172A] truncate">
                  Conexión JSON-RPC Odoo 17
                </span>
                <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                  Conectado
                </span>
              </div>
              <p className="text-[11px] text-[#64748B] truncate font-mono">
                {db} • {username}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setShowOdooConfig((prev) => !prev)}
            className="p-1.5 px-2.5 rounded-xl bg-slate-50 hover:bg-slate-100 text-[#64748B] hover:text-[#0F172A] border border-[#E2E8F0] text-xs font-medium cursor-pointer transition shrink-0 flex items-center gap-1"
            title="Revisar o cambiar credenciales Odoo"
          >
            <Settings className="w-3 h-3 text-[#7C3AED]" />
            <span>{showOdooConfig ? 'Ocultar' : 'Editar'}</span>
          </button>
        </div>

        {/* 3. ACORDEÓN / CONTENEDOR COLAPSABLE DE CREDENCIALES (CERRADO POR DEFECTO) */}
        {showOdooConfig && (
          <form
            onSubmit={handleAuthenticate}
            className="p-5 rounded-2xl bg-white border border-purple-200 shadow-md space-y-4 animate-in fade-in slide-in-from-top-2"
          >
            <div className="flex items-center justify-between pb-2 border-b border-[#E2E8F0]">
              <span className="text-xs font-bold uppercase tracking-wider text-[#7C3AED] flex items-center gap-1.5">
                <Server className="w-4 h-4" />
                Configuración de Servidor y Credenciales Odoo 17
              </span>
              <button
                type="button"
                onClick={() => setShowOdooConfig(false)}
                className="text-xs text-[#64748B] hover:text-[#0F172A] cursor-pointer"
              >
                Cerrar
              </button>
            </div>

            {/* URL del Servidor Odoo con Sanitización en vivo */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-xs font-medium text-[#0F172A]">
                  URL del Servidor Odoo:
                </label>
                <span className="text-[10px] text-[#7C3AED]">Sanitización automática</span>
              </div>
              <div className="relative">
                <Globe className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#64748B]" />
                <input
                  type="text"
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  placeholder="https://erp.pruebas.fvgrupoempresarial.com"
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white border border-[#CBD5E1] focus:border-[#7C3AED] focus:ring-1 focus:ring-[#7C3AED] text-xs sm:text-sm font-mono text-[#0F172A] placeholder-[#94A3B8] outline-none"
                />
              </div>

              {/* Vista previa de URL Sanitizada */}
              {sanitizedPreview && sanitizedPreview !== url && (
                <p className="text-[11px] text-emerald-600 font-mono truncate">
                  → Sanitizada a: <strong>{sanitizedPreview}</strong>
                </p>
              )}
            </div>

            {/* Base de Datos y Proxy CORS */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-[#0F172A]">
                  Base de Datos (db):
                </label>
                <div className="relative">
                  <Database className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#64748B]" />
                  <input
                    type="text"
                    value={db}
                    onChange={(e) => setDb(e.target.value)}
                    placeholder="odoo17_db"
                    className="w-full pl-10 pr-4 py-2 rounded-xl bg-white border border-[#CBD5E1] focus:border-[#7C3AED] text-xs font-mono text-[#0F172A] placeholder-[#94A3B8] outline-none"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-medium text-[#0F172A]">
                    Proxy / Conexión CORS:
                  </label>
                  <span className="text-[10px] text-[#7C3AED]">
                    {proxyUrl === 'direct' ? 'Sin Proxy (Directo)' : 'Reenvío Activo'}
                  </span>
                </div>
                <select
                  value={isCustomProxy ? 'custom' : proxyUrl}
                  onChange={(e) => {
                    const val = e.target.value;
                    if (val === 'custom') {
                      setIsCustomProxy(true);
                    } else {
                      setIsCustomProxy(false);
                      setProxyUrl(val);
                    }
                  }}
                  className="w-full px-3 py-2 rounded-xl bg-white border border-[#CBD5E1] focus:border-[#7C3AED] text-xs text-[#0F172A] outline-none"
                >
                  <option value="/api/odoo-proxy">Proxy Integrado (/api/odoo-proxy) ★ Recomendado</option>
                  <option value="direct">Petición Directa (Sin Proxy - CORS Odoo / Red Local)</option>
                  <option value="https://api.allorigins.win/raw?url=">api.allorigins.win (Proxy Alternativo)</option>
                  <option value="https://thingproxy.freeboard.io/fetch/">thingproxy.freeboard.io (Proxy Alternativo)</option>
                  <option value="https://api.codetabs.com/v1/proxy?quest=">api.codetabs.com (Proxy Alternativo)</option>
                  <option value="https://corsproxy.io/?">corsproxy.io (Aviso: Suele generar error 403)</option>
                  <option value="custom">Proxy Personalizado (Vercel Rewrite / URL Propia)...</option>
                </select>

                {isCustomProxy && (
                  <div className="mt-2 space-y-1 animate-in fade-in">
                    <input
                      type="text"
                      value={customProxyUrl}
                      onChange={(e) => setCustomProxyUrl(e.target.value)}
                      placeholder="Ej: https://mi-proxy.vercel.app/api?url="
                      className="w-full px-3 py-1.5 rounded-lg bg-white border border-[#7C3AED] text-xs font-mono text-[#0F172A] placeholder-[#94A3B8] outline-none"
                    />
                    <p className="text-[10px] text-[#64748B]">
                      Ingresa el prefijo de tu proxy Serverless o endpoint de reescritura.
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Usuario y Clave / API Key */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-[#0F172A]">
                  Usuario o Email:
                </label>
                <div className="relative">
                  <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#64748B]" />
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="usuario@fvgrupoempresarial.com"
                    className="w-full pl-10 pr-4 py-2 rounded-xl bg-white border border-[#CBD5E1] focus:border-[#7C3AED] text-xs text-[#0F172A] placeholder-[#94A3B8] outline-none"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-[#0F172A]">
                  Contraseña o API Key:
                </label>
                <div className="relative">
                  <Key className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#64748B]" />
                  <input
                    type="password"
                    value={apiKey}
                    onChange={(e) => setApiKey(e.target.value)}
                    placeholder="••••••••••••"
                    className="w-full pl-10 pr-4 py-2 rounded-xl bg-white border border-[#CBD5E1] focus:border-[#7C3AED] text-xs text-[#0F172A] placeholder-[#94A3B8] outline-none"
                  />
                </div>
              </div>
            </div>

            {/* Botón de Autenticación */}
            <div className="pt-1 flex items-center gap-2">
              <button
                type="submit"
                disabled={isLoadingAuth}
                className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl bg-[#F8FAFC] hover:bg-slate-100 text-[#0F172A] font-semibold text-xs transition cursor-pointer border border-[#E2E8F0] shadow-xs"
              >
                {isLoadingAuth ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin text-[#7C3AED]" />
                    <span>Autenticando en Odoo 17...</span>
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4 text-[#7C3AED]" />
                    <span>Re-verificar y Guardar Credenciales</span>
                  </>
                )}
              </button>
              <button
                type="button"
                onClick={() => setShowOdooConfig(false)}
                className="py-2.5 px-4 rounded-xl border border-[#E2E8F0] hover:bg-slate-50 text-xs text-[#64748B] font-medium transition cursor-pointer"
              >
                Listo
              </button>
            </div>
          </form>
        )}

        {/* Selector de Modo: Crear Sesión vs Unirse con PIN */}
        <div className="grid grid-cols-2 gap-2 p-1.5 rounded-2xl bg-slate-100 border border-[#E2E8F0]">
          <button
            type="button"
            onClick={() => {
              setSessionMode('create');
              setAuthError(null);
            }}
            className={`flex items-center justify-center gap-2 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all cursor-pointer ${
              sessionMode === 'create'
                ? 'bg-[#7C3AED] text-white shadow-sm'
                : 'text-[#64748B] hover:text-[#0F172A]'
            }`}
          >
            <Radio className="w-4 h-4" />
            <span>Crear Sesión (Lead)</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setSessionMode('join');
              setAuthError(null);
            }}
            className={`flex items-center justify-center gap-2 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all cursor-pointer ${
              sessionMode === 'join'
                ? 'bg-[#7C3AED] text-white shadow-sm'
                : 'text-[#64748B] hover:text-[#0F172A]'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Unirse con PIN</span>
          </button>
        </div>

        {/* Nombre del Auditor (Común a ambos modos) */}
        <div className="p-4 rounded-2xl bg-white border border-[#E2E8F0] shadow-[0_1px_3px_rgba(0,0,0,0.05)] space-y-3">
          <label className="block text-xs font-bold text-[#0F172A]">
            Nombre o Código del Auditor:
          </label>
          <div className="relative">
            <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#64748B]" />
            <input
              type="text"
              value={auditorName}
              onChange={(e) => setAuditorName(e.target.value)}
              placeholder="Ej: Carlos Gómez / Piso A"
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white border border-[#CBD5E1] focus:border-[#7C3AED] focus:ring-1 focus:ring-[#7C3AED] text-sm font-medium text-[#0F172A] placeholder-[#94A3B8] outline-none"
            />
          </div>
        </div>

        {/* CONTENIDO MODO: UNIRSE A SESIÓN POR PIN */}
        {sessionMode === 'join' && (
          <div className="p-5 rounded-2xl bg-white border border-[#E2E8F0] shadow-[0_1px_3px_rgba(0,0,0,0.05)] space-y-5">
            <div className="text-center space-y-1">
              <h2 className="text-base font-bold text-[#0F172A]">Ingresa el PIN de la Auditoría</h2>
              <p className="text-xs text-[#64748B]">
                Solicita el código de 4 dígitos al supervisor o creador de la sesión.
              </p>
            </div>

            <div className="max-w-xs mx-auto">
              <input
                type="text"
                inputMode="numeric"
                maxLength={4}
                value={joinPin}
                onChange={(e) => {
                  setJoinPin(e.target.value.replace(/\D/g, ''));
                  if (sessionNotFoundState) setSessionNotFoundState(null);
                  if (authError) setAuthError(null);
                }}
                placeholder="0000"
                disabled={isCheckingPin}
                className="w-full text-center text-4xl font-mono font-black tracking-widest py-3 rounded-2xl bg-white border-2 border-[#7C3AED] focus:border-[#6D28D9] focus:ring-4 focus:ring-[#7C3AED]/20 text-[#0F172A] outline-none disabled:opacity-50"
              />
            </div>

            <div className="flex items-center justify-center gap-2 -mt-2">
              <label className="flex items-center gap-2 cursor-pointer select-none text-[11px] text-[#64748B] hover:text-[#0F172A] transition">
                <input
                  type="checkbox"
                  checked={autoCreateOnJoin}
                  onChange={(e) => setAutoCreateOnJoin(e.target.checked)}
                  className="rounded bg-white border-[#CBD5E1] text-[#7C3AED] focus:ring-[#7C3AED] cursor-pointer"
                />
                <span>Crear sesión automáticamente si no existe en Supabase</span>
              </label>
            </div>

            {/* Tarjeta de Sesión No Encontrada con Opción de Creación */}
            {sessionNotFoundState && (
              <div className="p-4 rounded-2xl bg-amber-50 border border-amber-300 text-amber-800 text-xs space-y-3 animate-in fade-in">
                <div className="flex items-start gap-2.5">
                  <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <div>
                    <strong className="block text-amber-900 font-bold">
                      La sesión con PIN {sessionNotFoundState.pin} no existe en Supabase.
                    </strong>
                    <p className="text-[11px] text-amber-700 mt-0.5 leading-relaxed">
                      Aún no ha sido iniciada por otro auditor o el PIN es incorrecto. Puedes crearla ahora con este mismo PIN.
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2 pt-1">
                  <button
                    type="button"
                    disabled={isCreatingFromNotFound}
                    onClick={() => handleCreateSessionWithPin(sessionNotFoundState.pin)}
                    className="flex-1 py-2.5 px-3 rounded-xl bg-amber-600 hover:bg-amber-700 disabled:opacity-60 text-white font-bold text-xs cursor-pointer shadow-sm transition text-center flex items-center justify-center gap-2"
                  >
                    {isCreatingFromNotFound ? (
                      <>
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        <span>Guardando en Supabase (UPSERT)...</span>
                      </>
                    ) : (
                      <span>Crear Sesión con PIN {sessionNotFoundState.pin}</span>
                    )}
                  </button>
                  <button
                    type="button"
                    disabled={isCreatingFromNotFound}
                    onClick={() => setSessionNotFoundState(null)}
                    className="py-2.5 px-3 rounded-xl bg-white hover:bg-slate-100 text-[#64748B] text-xs cursor-pointer transition border border-[#E2E8F0]"
                  >
                    Cancelar
                  </button>
                </div>
              </div>
            )}

            <button
              type="button"
              onClick={handleJoinSession}
              disabled={joinPin.length !== 4 || isCheckingPin}
              className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-[#7C3AED] hover:bg-[#6D28D9] disabled:opacity-50 text-white font-bold text-sm shadow-md transition cursor-pointer"
            >
              {isCheckingPin ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-white" />
                  <span>Verificando sesión en Supabase...</span>
                </>
              ) : (
                <>
                  <span>Conectar y Sincronizar en Vivo</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </div>
        )}

        {/* CONTENIDO MODO: CREAR SESIÓN (OPCIONES DE ALMACÉN Y AUDITORÍA) */}
        {sessionMode === 'create' && (
          <div className="space-y-4">
            {/* PARTE 2: COMPAÑÍA, UBICACIÓN Y CATEGORÍA (Inmediatamente accesibles y limpias) */}
            <div className="p-5 rounded-2xl bg-white border border-[#E2E8F0] shadow-sm space-y-4 animate-in fade-in">
              <div className="flex items-center justify-between pb-2 border-b border-[#E2E8F0]">
                <span className="text-xs font-bold uppercase tracking-wider text-[#7C3AED] flex items-center gap-1.5">
                  <Building2 className="w-4 h-4" />
                  Filtros de Almacén y Auditoría
                </span>
                <span className="text-xs text-emerald-700 font-semibold bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                  Multicompañía Odoo 17
                </span>
              </div>

              {/* Selector de Compañía */}
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-[#0F172A]">
                  Compañía Odoo:
                </label>
                <select
                  value={selectedCompanyId}
                  onChange={(e) => setSelectedCompanyId(Number(e.target.value))}
                  className="w-full px-3 py-2.5 rounded-xl bg-white border border-[#CBD5E1] focus:border-[#7C3AED] text-xs font-semibold text-[#0F172A] outline-none"
                >
                  {companies.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} {c.name.includes('FV') ? '★ (Predeterminada)' : ''}
                    </option>
                  ))}
                  {companies.length === 0 && (
                    <option value={1}>FV GRUPO EMPRESARIAL, C.A.</option>
                  )}
                </select>
              </div>

              {/* Selector de Ubicación (stock.location) */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-medium text-[#0F172A] flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-[#7C3AED]" />
                    Ubicación Física (stock.location):
                  </label>
                  <span className="text-[10px] text-[#64748B]">complete_name</span>
                </div>
                <select
                  value={selectedLocationId || ''}
                  onChange={(e) => setSelectedLocationId(e.target.value ? Number(e.target.value) : undefined)}
                  className="w-full px-3 py-2.5 rounded-xl bg-white border border-[#CBD5E1] focus:border-[#7C3AED] text-xs text-[#0F172A] outline-none"
                >
                  <option value="">Todas las ubicaciones internas</option>
                  {locations.map((loc) => (
                    <option key={loc.id} value={loc.id}>
                      {loc.complete_name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Selector de Categoría (product.category) */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-medium text-[#0F172A] flex items-center gap-1">
                    <Tag className="w-3.5 h-3.5 text-[#7C3AED]" />
                    Categoría de Producto (product.category):
                  </label>
                  <span className="text-[10px] text-[#64748B]">{deduplicatedCategories.length} únicas</span>
                </div>
                <select
                  value={selectedCategoryId || ''}
                  onChange={(e) => setSelectedCategoryId(e.target.value ? Number(e.target.value) : undefined)}
                  className="w-full px-3 py-2.5 rounded-xl bg-white border border-[#CBD5E1] focus:border-[#7C3AED] text-xs text-[#0F172A] outline-none"
                >
                  <option value="">Todas las categorías (100%)</option>
                  {deduplicatedCategories.map((cat) => (
                    <option key={cat.id} value={cat.id}>
                      {cat.complete_name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Botón para Iniciar Sesión de Auditoría */}
              {customPin && (
                <div className="p-3 rounded-xl bg-purple-50 border border-purple-200 flex items-center justify-between text-xs text-[#7C3AED]">
                  <div className="flex items-center gap-2">
                    <Key className="w-4 h-4 text-[#7C3AED]" />
                    <span>PIN para la nueva sesión: <strong className="font-mono text-[#0F172A] text-sm">{customPin}</strong></span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setCustomPin(null)}
                    className="text-[11px] text-[#64748B] hover:text-[#0F172A] underline cursor-pointer"
                  >
                    Usar PIN aleatorio
                  </button>
                </div>
              )}

              <button
                type="button"
                disabled={isCreatingSession}
                onClick={handleStartNewSession}
                className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-[#7C3AED] hover:bg-[#6D28D9] disabled:opacity-75 disabled:cursor-not-allowed text-white font-bold text-sm shadow-md shadow-[#7C3AED]/25 transition active:scale-98 cursor-pointer"
              >
                {isCreatingSession ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-white" />
                    <span>Guardando sesión en Supabase (UPSERT)...</span>
                  </>
                ) : (
                  <>
                    <span>{customPin ? `Crear Sesión con PIN ${customPin}` : 'Generar PIN y Abrir Sesión de Auditoría'}</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          </div>
        )}

      {/* Mensaje de Error si ocurre */}
      {authError && (
        <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-300 text-rose-800 text-xs flex items-start gap-2.5">
          <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <strong className="block text-rose-900">Aviso de Conexión:</strong>
            <p>{authError}</p>
          </div>
        </div>
      )}

      {/* ACCIONES RÁPIDAS Y CONFIGURACIÓN SECUNDARIA */}
      <div className="space-y-3 pt-2">
        {/* Botón para probar Modo Demo Inmediato */}
        <button
          type="button"
          onClick={handleStartDemo}
          className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-gradient-to-r from-purple-50 to-indigo-50 hover:from-purple-100 hover:to-indigo-100 border border-purple-200 text-[#7C3AED] text-xs font-semibold shadow-xs transition cursor-pointer"
        >
          <Sparkles className="w-4 h-4 text-amber-500" />
          <span>Probar con Datos Demo "FV GRUPO EMPRESARIAL, C.A."</span>
        </button>

        {/* Acordeón para Configurar Supabase Realtime */}
        <div className="rounded-xl border border-[#E2E8F0] bg-white overflow-hidden text-xs shadow-xs">
          <button
            type="button"
            onClick={() => setShowSupabaseSettings(!showSupabaseSettings)}
            className="w-full flex items-center justify-between p-3 text-[#64748B] hover:text-[#0F172A] cursor-pointer"
          >
            <span className="flex items-center gap-2 font-medium">
              <Radio className="w-3.5 h-3.5 text-[#7C3AED]" />
              Configurar Supabase Realtime (URL y Clave Anon)
            </span>
            <ChevronDown
              className={`w-4 h-4 transition-transform ${
                showSupabaseSettings ? 'rotate-180' : ''
              }`}
            />
          </button>

          {showSupabaseSettings && (
            <div className="p-3.5 pt-1 space-y-3 border-t border-[#E2E8F0] bg-[#F8FAFC]">
              <p className="text-[11px] text-[#64748B]">
                La app sincroniza en tiempo real de forma nativa a través de la nube de Supabase (tablas <code className="text-[#7C3AED]">audit_sessions</code> y <code className="text-[#7C3AED]">audit_items</code>). Credenciales predeterminadas del proyecto:
              </p>

              <div className="space-y-1">
                <label className="text-[11px] font-medium text-[#0F172A]">Supabase Project URL:</label>
                <input
                  type="text"
                  value={supabaseSettings.url}
                  onChange={(e) => setSupabaseSettingsState({ ...supabaseSettings, url: e.target.value.trim() })}
                  placeholder={DEFAULT_SUPABASE_URL}
                  className="w-full px-3 py-1.5 rounded-lg bg-white border border-[#CBD5E1] text-xs font-mono text-[#0F172A] outline-none"
                />
              </div>

              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <label className="text-[11px] font-medium text-[#0F172A]">Supabase Publishable / Anon Public Key:</label>
                  <a
                    href="https://supabase.com/dashboard/project/sepeawvmamugivoptfyf/settings/api"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[10px] text-[#7C3AED] hover:underline"
                  >
                    Obtener en Supabase ↗
                  </a>
                </div>
                <textarea
                  rows={2}
                  value={supabaseSettings.anonKey}
                  onChange={(e) => setSupabaseSettingsState({ ...supabaseSettings, anonKey: e.target.value.trim() })}
                  placeholder="Pega aquí la clave completa (eyJ... o sb_publishable_...)"
                  className="w-full px-3 py-1.5 rounded-lg bg-white border border-[#CBD5E1] text-xs font-mono text-[#0F172A] outline-none focus:border-[#7C3AED] resize-none"
                />
                <p className="text-[10px] text-amber-700">
                  * Debe ser la cadena completa copiada de Supabase (las claves anon públicas estándar empiezan por <span className="font-mono text-[#0F172A]">eyJhbGciOi...</span>).
                </p>
              </div>

              <div className="flex items-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={handleSaveSupabase}
                  className="flex-1 py-2 rounded-lg bg-[#7C3AED] hover:bg-[#6D28D9] text-white font-semibold text-xs transition cursor-pointer"
                >
                  Guardar Credenciales
                </button>
                <button
                  type="button"
                  onClick={async () => {
                    const testUrl = supabaseSettings.url.trim();
                    const testKey = supabaseSettings.anonKey.trim();
                    if (!testUrl || !testKey) {
                      setAuthError('Por favor ingresa la URL y la clave completa de Supabase.');
                      return;
                    }
                    try {
                      const { createClient } = await import('@supabase/supabase-js');
                      const client = createClient(testUrl, testKey);
                      const { error } = await client.from('audit_sessions').select('id').limit(1);
                      if (error && (error.message.includes('Invalid API key') || (error as any).status === 401)) {
                        sound.playError();
                        setAuthError('Error: "Invalid API key". La clave de Supabase está incompleta o es inválida. Asegúrate de copiar la cadena completa sin puntos suspensivos.');
                      } else {
                        sound.playSuccess();
                        setAuthError(null);
                        alert('✓ Conexión con Supabase verificada exitosamente.');
                      }
                    } catch (err: any) {
                      sound.playError();
                      setAuthError(`Error de conexión con Supabase: ${err.message || String(err)}`);
                    }
                  }}
                  className="py-2 px-3 rounded-lg bg-white hover:bg-slate-100 border border-[#E2E8F0] text-[#0F172A] font-medium text-xs transition cursor-pointer"
                  title="Comprobar si la clave y la URL son válidas"
                >
                  Probar Conexión
                </button>
              </div>

              {/* Botón para ver y copiar el Script SQL de Supabase */}
              <div className="pt-2 border-t border-[#E2E8F0]">
                <button
                  type="button"
                  onClick={() => setShowSqlSchema(!showSqlSchema)}
                  className="flex items-center gap-1.5 text-[11px] text-[#7C3AED] hover:underline font-semibold cursor-pointer"
                >
                  <Code2 className="w-3.5 h-3.5" />
                  <span>{showSqlSchema ? 'Ocultar' : 'Ver'} Script SQL para Supabase (Tablas audit_sessions, audit_items y RLS)</span>
                </button>

                {showSqlSchema && (
                  <div className="mt-2 p-2.5 rounded-xl bg-white border border-[#E2E8F0] space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] text-[#64748B] font-mono">audit_schema_rls.sql</span>
                      <button
                        type="button"
                        onClick={() => {
                          navigator.clipboard.writeText(SUPABASE_SQL_SCHEMA);
                          setCopiedSql(true);
                          setTimeout(() => setCopiedSql(false), 2000);
                        }}
                        className="flex items-center gap-1 text-[10px] text-[#7C3AED] hover:underline cursor-pointer"
                      >
                        {copiedSql ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                        <span>{copiedSql ? 'Copiado' : 'Copiar SQL'}</span>
                      </button>
                    </div>
                    <pre className="font-mono text-[9px] text-[#0F172A] overflow-x-auto p-2 rounded bg-[#F8FAFC] border border-[#E2E8F0] max-h-44 leading-relaxed">
                      {SUPABASE_SQL_SCHEMA}
                    </pre>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Botón para descargar el código del proyecto completo */}
          <div className="pt-2 border-t border-[#E2E8F0] flex items-center justify-between">
            <span className="text-[11px] text-[#64748B]">¿Deseas ejecutar o modificar localmente?</span>
            <a
              href="/odoo-audit-app.zip"
              download="odoo-audit-app.zip"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#F8FAFC] hover:bg-purple-50 border border-[#E2E8F0] hover:border-purple-300 text-[11px] font-medium text-[#7C3AED] transition cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              Descargar Código (.ZIP)
            </a>
          </div>
        </div>
      </div>
    </div>
    </div>
  );
};
